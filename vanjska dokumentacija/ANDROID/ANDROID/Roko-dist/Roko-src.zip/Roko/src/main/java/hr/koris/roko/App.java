package hr.koris.roko;

import android.app.Application;

public class App extends Application {
    public static byte[] MosiKey;
    public static byte[] SeopKeyF2;
    public static byte[] SeopKeyF3;
    public static byte[] JadrolinijaKey;
}