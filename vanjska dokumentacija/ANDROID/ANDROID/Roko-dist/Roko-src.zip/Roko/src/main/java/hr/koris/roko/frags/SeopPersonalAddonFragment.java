package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Locale;

import hr.akd.tesserapojos.cardsettings.SeopCardSettings;
import hr.koris.roko.R;

public class SeopPersonalAddonFragment extends Fragment {
    final SimpleDateFormat datum = new SimpleDateFormat(SeopCardSettings.DATE_FORMAT, new Locale("hr"));

    TextView vDatRod;
    TextView vDatIstekaOI;
    TextView vBorUlicaKBr;
    TextView vBorMjesto;
    TextView vBorOznMjesta;
    TextView vBorOpcina;
    TextView vBorOznOpcine;
    TextView vSpol;
    TextView vDrzavljanstvo;
    TextView vDodatnoPolje1;
    TextView vDodatnoPolje2;
    TextView vDodatnoPolje3;
    TextView vDodatnoPolje4;
    TextView vDodatnoPolje5;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_seop_p_addon, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vDatRod = v.findViewById(R.id.SEOP_P_DateOfBirth);
        vDatIstekaOI = v.findViewById(R.id.SEOP_P_IdCardExpDate);
        vBorUlicaKBr = v.findViewById(R.id.SEOP_P_TempResAddress);
        vBorMjesto = v.findViewById(R.id.SEOP_P_TempResName);
        vBorOznMjesta = v.findViewById(R.id.SEOP_P_TempResCode);
        vBorOpcina = v.findViewById(R.id.SEOP_P_TempResMuniciName);
        vBorOznOpcine = v.findViewById(R.id.SEOP_P_TempResMuniciCode);
        vSpol = v.findViewById(R.id.SEOP_P_Gender);
        vDrzavljanstvo = v.findViewById(R.id.SEOP_P_Nationality);
        vDodatnoPolje1 = v.findViewById(R.id.SEOP_P_AdditionalField1);
        vDodatnoPolje2 = v.findViewById(R.id.SEOP_P_AdditionalField2);
        vDodatnoPolje3 = v.findViewById(R.id.SEOP_P_AdditionalField3);
        vDodatnoPolje4 = v.findViewById(R.id.SEOP_P_AdditionalField4);
        vDodatnoPolje5 = v.findViewById(R.id.SEOP_P_AdditionalField5);
    }

    public void fill(hr.akd.tesserapojos.cardfiles.akd.seop.personal.F3_AddonData f) {
        vDatRod.setText(f.DateOfBirth == null ? "" :  datum.format(f.DateOfBirth));
        vDatIstekaOI.setText(f.IdCardExpDate == null ? "" : datum.format(f.IdCardExpDate));
        vBorUlicaKBr.setText(f.TempResAddress);
        vBorMjesto.setText(f.TempResName);
        vBorOznMjesta.setText(f.TempResCode);
        vBorOpcina.setText(f.TempResMuniciName);
        vBorOznOpcine.setText(f.TempResMuniciCode);
        vSpol.setText(f.Gender == null ? "" : f.Gender.toString());
        vDrzavljanstvo.setText(f.Nationality);
        vDodatnoPolje1.setText(f.AdditionalField1);
        vDodatnoPolje2.setText(f.AdditionalField2);
        vDodatnoPolje3.setText(f.AdditionalField3);
        vDodatnoPolje4.setText(f.AdditionalField4);
        vDodatnoPolje5.setText(f.AdditionalField5);
    }
}
