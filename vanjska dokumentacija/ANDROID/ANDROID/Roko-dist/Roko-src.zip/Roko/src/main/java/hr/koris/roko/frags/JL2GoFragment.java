package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Locale;

import hr.akd.tesserapojos.cardsettings.SeopCardSettings;
import hr.koris.roko.R;

public class JL2GoFragment extends Fragment {
    final SimpleDateFormat datum = new SimpleDateFormat(SeopCardSettings.DATE_FORMAT, new Locale("hr"));

    TextView vIdKartice;
    TextView vBrKartice;
    TextView vTipKartice;
    TextView vDatIsteka;
    TextView vIme;
    TextView vPrezime;
    TextView vDatRod;
    TextView vNaziv;
    TextView vSpol;
    TextView vDrzavljanstvo;
    TextView vUlicaKBr;
    TextView vMjesto;
    TextView vPBr;
    TextView vOIB;
    TextView vRegOzn;
    TextView vNosivost;
    TextView vBrSjedala;
    TextView vDuljina;
    TextView vSirina;
    TextView vVisina;
    TextView vKategorijaVozila;
    TextView vDodatnoPolje1;
    TextView vDodatnoPolje2;
    TextView vDodatnoPolje3;
    TextView vDodatnoPolje4;
    TextView vDodatnoPolje5;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_jl2go, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vIdKartice = v.findViewById(R.id.JL2Go_CardOpp);
        vBrKartice = v.findViewById(R.id.JL2Go_CardNumber);
        vTipKartice = v.findViewById(R.id.JL2Go_CardType);
        vDatIsteka = v.findViewById(R.id.JL2Go_ValidTo);
        vIme = v.findViewById(R.id.JL2Go_Name);
        vPrezime = v.findViewById(R.id.JL2Go_Surname);
        vDatRod = v.findViewById(R.id.JL2Go_DateOfBirth);
        vNaziv = v.findViewById(R.id.JL2Go_Title);
        vSpol = v.findViewById(R.id.JL2Go_Gender);
        vDrzavljanstvo = v.findViewById(R.id.JL2Go_Nationality);
        vUlicaKBr = v.findViewById(R.id.JL2Go_Address);
        vMjesto = v.findViewById(R.id.JL2Go_Place);
        vPBr = v.findViewById(R.id.JL2Go_PBr);
        vOIB = v.findViewById(R.id.JL2Go_OIB);
        vRegOzn = v.findViewById(R.id.JL2Go_RegistrationTag);
        vNosivost = v.findViewById(R.id.JL2Go_Capacity);
        vBrSjedala = v.findViewById(R.id.JL2Go_SeatsNumber);
        vDuljina = v.findViewById(R.id.JL2Go_VehicleLength);
        vSirina = v.findViewById(R.id.JL2Go_VehicleWidth);
        vVisina = v.findViewById(R.id.JL2Go_VehicleHeight);
        vKategorijaVozila = v.findViewById(R.id.JL2Go_VehicleType);
        vDodatnoPolje1 = v.findViewById(R.id.JL2Go_AdditionalField1);
        vDodatnoPolje2 = v.findViewById(R.id.JL2Go_AdditionalField2);
        vDodatnoPolje3 = v.findViewById(R.id.JL2Go_AdditionalField3);
        vDodatnoPolje4 = v.findViewById(R.id.JL2Go_AdditionalField4);
        vDodatnoPolje5 = v.findViewById(R.id.JL2Go_AdditionalField5);
    }

    public void fill(hr.akd.tesserapojos.cardfiles.jl2go.JL2GoFile f) {
        vIdKartice.setText(String.valueOf(f.CardOpp));
        vBrKartice.setText(f.CardNumber);
        vTipKartice.setText(f.JadrolinijaCardType);
        vDatIsteka.setText(f.ValidTo == null ? "" : datum.format(f.ValidTo));
        vIme.setText(f.Name);
        vPrezime.setText(f.SurName);
        vDatRod.setText(f.DateOfBirth == null ? "" : datum.format(f.DateOfBirth));
        vNaziv.setText(f.Title);
        vSpol.setText(f.Gender);
        vDrzavljanstvo.setText(f.Nationality);
        vUlicaKBr.setText(f.Address);
        vMjesto.setText(f.Place);
        vPBr.setText(f.PBr);
        vOIB.setText(f.OIB);
        vRegOzn.setText(f.RegistrationTag);
        vNosivost.setText(f.Capacity);
        vBrSjedala.setText(String.valueOf(f.SeatsNumber));
        vDuljina.setText(String.valueOf(f.VehicleLength));
        vSirina.setText(String.valueOf(f.VehicleWidth));
        vVisina.setText(String.valueOf(f.VehicleHeight));
        vKategorijaVozila.setText(f.VehicleType);
        vDodatnoPolje1.setText(f.AdditionalField1);
        vDodatnoPolje2.setText(f.AdditionalField2);
        vDodatnoPolje3.setText(f.AdditionalField3);
        vDodatnoPolje4.setText(f.AdditionalField4);
        vDodatnoPolje5.setText(f.AdditionalField5);
    }
}