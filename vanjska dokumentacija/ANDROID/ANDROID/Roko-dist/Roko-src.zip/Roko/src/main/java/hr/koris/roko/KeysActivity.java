package hr.koris.roko;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class KeysActivity extends AppCompatActivity {
    AppCompatActivity currentActivity;
    EditText eMosiKey;
    EditText eSeopKeyF2;
    EditText eSeopKeyF3;
    EditText eJL2GoKey;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_keys);

        currentActivity = this;
        eMosiKey = findViewById(R.id.MosiKey);
        eSeopKeyF2 = findViewById(R.id.SeopKeyF2);
        eSeopKeyF3 = findViewById(R.id.SeopKeyF3);
        eJL2GoKey = findViewById(R.id.JL2GoKey);
        btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new SaveOnClickListener());
        try {
            StringBuilder sb = new StringBuilder();
            if (App.MosiKey != null) {
                for (byte b : App.MosiKey) {
                    sb.append(String.format("%02X", b));
                }
                eMosiKey.setText(sb.toString());
            }
            if (App.SeopKeyF2 != null) {
                for (byte b: App.SeopKeyF2) {
                    sb.append(String.format("%02X", b));
                }
                eSeopKeyF2.setText(sb.toString());
            }
            if (App.SeopKeyF3 != null) {
                for (byte b: App.SeopKeyF3) {
                    sb.append(String.format("%02X", b));
                }
                eSeopKeyF3.setText(sb.toString());
            }
            if (App.JadrolinijaKey != null) {
                for (byte b: App.JadrolinijaKey) {
                    sb.append(String.format("%02X", b));
                }
                eJL2GoKey.setText(sb.toString());
            }
            // Postavi naslov.
            ActionBar traka = this.getSupportActionBar();
            if (traka != null) {
                traka.setTitle(getString(R.string.AppName) + " " + this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName);
            }
        } catch (Exception e) {
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private class SaveOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            String hexMosiKey = eMosiKey.getText().toString().trim();
            String hexSeopKeyF2 = eSeopKeyF2.getText().toString().trim();
            String hexSeopKeyF3 = eSeopKeyF3.getText().toString().trim();
            String hexJL2GoKey = eJL2GoKey.getText().toString().trim();
            try {
                if (hexMosiKey.isEmpty()) {
                    App.MosiKey = null;
                } else {
                    byte[] a = new byte[hexMosiKey.length() / 2];
                    for (int i = 0; i < hexMosiKey.length(); i += 2) {
                        a[i / 2] = (byte) ((Character.digit(hexMosiKey.charAt(i), 16) << 4) + Character.digit(hexMosiKey.charAt(i + 1), 16));
                    }
                    App.MosiKey = a;
                }

                if (hexSeopKeyF2.isEmpty()) {
                    App.SeopKeyF2 = null;
                } else {
                    byte[] a = new byte[hexSeopKeyF2.length() / 2];
                    for (int i = 0; i < hexSeopKeyF2.length(); i += 2) {
                        a[i / 2] = (byte) ((Character.digit(hexSeopKeyF2.charAt(i), 16) << 4) + Character.digit(hexSeopKeyF2.charAt(i + 1), 16));
                    }
                    App.SeopKeyF2 = a;
                }

                if (hexSeopKeyF3.isEmpty()) {
                    App.SeopKeyF3 = null;
                } else {
                    byte[] a = new byte[hexSeopKeyF3.length() / 2];
                    for (int i = 0; i < hexSeopKeyF3.length(); i += 2) {
                        a[i / 2] = (byte) ((Character.digit(hexSeopKeyF3.charAt(i), 16) << 4) + Character.digit(hexSeopKeyF3.charAt(i + 1), 16));
                    }
                    App.SeopKeyF3 = a;
                }

                if (hexJL2GoKey.isEmpty()) {
                    App.JadrolinijaKey = null;
                } else {
                    byte[] a = new byte[hexJL2GoKey.length() / 2];
                    for (int i = 0; i < hexJL2GoKey.length(); i += 2) {
                        a[i / 2] = (byte) ((Character.digit(hexJL2GoKey.charAt(i), 16) << 4) + Character.digit(hexJL2GoKey.charAt(i + 1), 16));
                    }
                    App.JadrolinijaKey = a;
                }
            } catch (Exception e) {
                //noinspection CallToPrintStackTrace
                e.printStackTrace();
                Toast.makeText(currentActivity, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}