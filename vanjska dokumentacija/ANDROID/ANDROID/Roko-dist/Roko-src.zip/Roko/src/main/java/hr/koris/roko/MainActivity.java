package hr.koris.roko;

import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.nxp.nfclib.NxpNfcLib;
import com.nxp.nfclib.exceptions.NxpNfcLibException;

import java.util.Objects;

import hr.akd.tessera.Card;
import hr.akd.tessera.CardController;
import hr.akd.tessera.kartice.akd.AkdCard;
import hr.akd.tessera.kartice.akd.mosi.MosiCard;
import hr.akd.tessera.kartice.akd.seop.SeopCardPersonal;
import hr.akd.tessera.kartice.akd.seop.SeopCardVehicle;
import hr.akd.tessera.kartice.iks.StudentCard2023;
import hr.akd.tessera.kartice.iks.StudentCardLegacy;
import hr.akd.tessera.kartice.jl.JL2GoCard;
import hr.akd.tesserapojos.CardKeys;
import hr.koris.roko.frags.AkdBizDataFragment;
import hr.koris.roko.frags.JL2GoFragment;
import hr.koris.roko.frags.MosiFragment;
import hr.koris.roko.frags.SeopPersonalAddonFragment;
import hr.koris.roko.frags.SeopPersonalBasicFragment;
import hr.koris.roko.frags.SeopVehicleAddonFragment;
import hr.koris.roko.frags.SeopVehicleBasicFragment;
import hr.koris.roko.frags.TecDataFragment;

public class MainActivity extends AppCompatActivity {
    /** @noinspection FieldCanBeLocal*/
    private final String tapLinxKey = "ac75501790398e556bc059d8cdf1de30";
    private NxpNfcLib nxpNfcLib = null;
    Card card; // Očitana kartica. Deklariramo ju ovdje kako bismo mogli obavljati spremanje i obnovu stanja.
    private static final String PARCELED_CARD_KEY = "kard"; // Ključ za očitanu karticu u "bundleu".
    Ringtone ringtone;
    TextView vLastCard;
    FrameLayout frameAkdBizData;
    FrameLayout frameMOSI;
    FrameLayout frameSeopPersonalBasic;
    FrameLayout frameSeopPersonalAddon;
    FrameLayout frameSeopVehicleBasic;
    FrameLayout frameSeopVehicleAddon;
    FrameLayout frameJL2Go;

    enum CardDescription {
        MOSI,
        SEOP_P,
        SEOP_V,
        JL2Go,
        ELSE
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupGUI();
        try {
            NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(this);
            if (nfcAdapter == null) {
                Toast.makeText(this, R.string.ErrNoNFC, Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            if (!nfcAdapter.isEnabled()) {
                Toast.makeText(this, R.string.ErrDisabledNFC, Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            // Pokreni biblioteku.
            nxpNfcLib = NxpNfcLib.getInstance();
            // Postavi naslov.
            ActionBar traka = this.getSupportActionBar();
            if (traka != null) {
                traka.setTitle(getString(R.string.AppName) + " " + this.getPackageManager().getPackageInfo(this.getPackageName(), 0).versionName);
            }
        } catch (Exception e) {
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // Obnova stanja. Klasa Card podržava spremanje svojih objekata u "bundle"!
        card = savedInstanceState.getParcelable(PARCELED_CARD_KEY);
        fill();
    }

    @Override
    protected void onResume() {
        nxpNfcLib.registerActivity(this, tapLinxKey); // Vidi: https://www.mifare.net/support/forum/topic/crash-when-executing-startforegrounddispatch/
        nxpNfcLib.startForeGroundDispatch();
        super.onResume();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        // Spremanje stanja. Klasa Card podržava spremanje svojih objekata u "bundle"!
        if (card != null) {
            outState.putParcelable(PARCELED_CARD_KEY, card);
        }
    }

    @Override
    protected void onPause() {
        nxpNfcLib.stopForeGroundDispatch();
        super.onPause();
    }

    @Override
    protected void onNewIntent(@NonNull Intent intent) {
        try {
            // Pokušaj čitanja iskaznice.
            CardKeys keys = new CardKeys();

            keys.MosiKeyF2 = App.MosiKey == null ? CardKeys.TEST_MOSI_F2_BASIC_DATA_KEY : App.MosiKey;
            keys.SeopKeyF2 = App.SeopKeyF2 == null ? CardKeys.TEST_SEOP_F2_BASIC_DATA_KEY : App.SeopKeyF2;
            keys.SeopKeyF3 = App.SeopKeyF3 == null ? CardKeys.TEST_SEOP_F3_ADDON_DATA_KEY : App.SeopKeyF3;
            keys.JL2GoKey = App.JadrolinijaKey == null ? CardKeys.TEST_JL2GO_KEY: App.JadrolinijaKey;
            // Ovdje dodati druge ključe.

            card = CardController.cardLogic(intent, nxpNfcLib, keys);
            ringtone.play(); // Zadani notifikacijski zvuk svira se po ZAVRŠETKU čitanja kartice.
            fill();
        } catch (NxpNfcLibException nxpExc) {
            // Ova iznimka se podiže:
            // 1. ako kartica nije prepoznata - "Instruction not supported" - ili
            // 2. ako je kartica prebrzo provučena (nxpExc.getMessage je null)
            if (nxpExc.getMessage() != null) {
                //noinspection CallToPrintStackTrace
                nxpExc.printStackTrace();
                Toast.makeText(
                        this,
                        nxpExc.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            } else {
                //noinspection CallToPrintStackTrace
                nxpExc.printStackTrace();
                Toast.makeText(this, "Kartica je prebrzo provučena.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception ex) {
            //noinspection CallToPrintStackTrace
            ex.printStackTrace();
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
        }
        super.onNewIntent(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.itemMosiDemo) {
            Intent intent = new Intent(this, hr.akd.tesserademo.MainActivity.class);
            this.startActivity(intent);
        } else if (item.getItemId() == R.id.itemKeys) {
            Intent intent = new Intent(this, KeysActivity.class);
            this.startActivity(intent);
        } else {
            System.exit(0);
        }
        return true;
    }

    private void setupGUI() {
        // Za sviranje notifikacije nakon ZAVRŠETKA očitanja kartice.
        ringtone = RingtoneManager.getRingtone(getApplicationContext(), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));

        vLastCard = findViewById(R.id.LastCard);
        frameAkdBizData = findViewById(R.id.FrameAkdBizData);
        frameMOSI = findViewById(R.id.FrameMOSI);
        frameSeopPersonalBasic = findViewById(R.id.FrameSeopPersonalBasic);
        frameSeopPersonalAddon = findViewById(R.id.FrameSeopPersonalAddon);
        frameSeopVehicleBasic = findViewById(R.id.FrameSeopVehicleBasic);
        frameSeopVehicleAddon = findViewById(R.id.FrameSeopVehicleAddon);
        frameJL2Go = findViewById(R.id.FrameJL2Go);

        setVisibilities(CardDescription.ELSE, getString(R.string.OcitajKarticu) );
    }

    private void fill() {
        if (card == null) { return; } // Linija je nužna ako je promjena orijentacije izvedena BEZ prethodnog očitanja kartice.

        // Tehnički podaci kartice se uvijek prikazuju.
        TecDataFragment tecDataFrag = (TecDataFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentTecData);
        Objects.requireNonNull(tecDataFrag).fill(card);

        // Ako je kartica AKD-ova uvijek treba napuniti poslovne podatke.
        if (card instanceof AkdCard) {
            AkdBizDataFragment akdBizDataFrag = (AkdBizDataFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentAkdBizData);
            Objects.requireNonNull(akdBizDataFrag).fill(((AkdCard) card).F1);
        }

        if (card instanceof MosiCard) {
            setVisibilities(CardDescription.MOSI, getString(R.string.MosiIskaznica));
            MosiFragment mosiFrag = (MosiFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentMOSI);
            Objects.requireNonNull(mosiFrag).currentActivity = this;
            Objects.requireNonNull(mosiFrag).fill(((MosiCard) card).F2);
        } else if (card instanceof SeopCardPersonal) {
            setVisibilities(CardDescription.SEOP_P, getString(R.string.SeopIskaznicaP));
            SeopPersonalBasicFragment seopPBfrag = (SeopPersonalBasicFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentSeopPersonalBasic);
            Objects.requireNonNull(seopPBfrag).fill(((SeopCardPersonal) card).F2);
            SeopPersonalAddonFragment seopPAfrag = (SeopPersonalAddonFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentSeopPersonalAddon);
            Objects.requireNonNull(seopPAfrag).fill(((SeopCardPersonal) card).F3);
        } else if (card instanceof SeopCardVehicle) {
            setVisibilities(CardDescription.SEOP_V, getString((R.string.SeopIskaznicaV)));
            SeopVehicleBasicFragment seopVBfrag = (SeopVehicleBasicFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentSeopVehicleBasic);
            Objects.requireNonNull(seopVBfrag).fill(((SeopCardVehicle) card).F2);
            SeopVehicleAddonFragment seopVAfrag = (SeopVehicleAddonFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentSeopVehicleAddon);
            Objects.requireNonNull(seopVAfrag).fill(((SeopCardVehicle) card).F3);
        } else if (card instanceof JL2GoCard) {
            setVisibilities(CardDescription.JL2Go, getString(R.string.JL2GoIskaznica));

            JL2GoFragment jl2GoFrag = (JL2GoFragment) getSupportFragmentManager().findFragmentById(R.id.FragmentJL2Go);
            Objects.requireNonNull(jl2GoFrag).fill(((JL2GoCard) card).F);
        } else if (card instanceof StudentCard2023) {
            setVisibilities(CardDescription.ELSE, getString(R.string.IKS2023));
        } else if (card instanceof StudentCardLegacy) {
            setVisibilities(CardDescription.ELSE, getString(R.string.IksLegacy));
        } else {
            setVisibilities(CardDescription.ELSE, getString(R.string.GenericCard));
        }
    }

    private void setVisibilities(CardDescription cardDescription, String lastCard) {
        // Kontrola frameTecData je NAVEK vidljiva.
        vLastCard.setText(lastCard);
        switch (cardDescription) {
            case MOSI:
                frameAkdBizData.setVisibility(View.VISIBLE);
                frameMOSI.setVisibility(View.VISIBLE);
                frameSeopPersonalBasic.setVisibility(View.GONE);
                frameSeopPersonalAddon.setVisibility(View.GONE);
                frameSeopVehicleBasic.setVisibility(View.GONE);
                frameSeopVehicleAddon.setVisibility(View.GONE);
                frameJL2Go.setVisibility(View.GONE);
                break;
            case SEOP_P:
                frameAkdBizData.setVisibility(View.VISIBLE);
                frameMOSI.setVisibility(View.GONE);
                frameSeopPersonalBasic.setVisibility(View.VISIBLE);
                frameSeopPersonalAddon.setVisibility(View.VISIBLE);
                frameSeopVehicleBasic.setVisibility(View.GONE);
                frameSeopVehicleAddon.setVisibility(View.GONE);
                frameJL2Go.setVisibility(View.GONE);
                break;
            case SEOP_V:
                frameAkdBizData.setVisibility(View.VISIBLE);
                frameMOSI.setVisibility(View.GONE);
                frameSeopPersonalBasic.setVisibility(View.GONE);
                frameSeopPersonalAddon.setVisibility(View.GONE);
                frameSeopVehicleBasic.setVisibility(View.VISIBLE);
                frameSeopVehicleAddon.setVisibility(View.VISIBLE);
                frameJL2Go.setVisibility(View.GONE);
                break;
            case JL2Go:
                frameAkdBizData.setVisibility(View.GONE);
                frameMOSI.setVisibility(View.GONE);
                frameSeopPersonalBasic.setVisibility(View.GONE);
                frameSeopPersonalAddon.setVisibility(View.GONE);
                frameSeopVehicleBasic.setVisibility(View.GONE);
                frameSeopVehicleAddon.setVisibility(View.GONE);
                frameJL2Go.setVisibility(View.VISIBLE);
                break;
            case ELSE:
                frameAkdBizData.setVisibility(View.GONE);
                frameMOSI.setVisibility(View.GONE);
                frameSeopPersonalBasic.setVisibility(View.GONE);
                frameSeopPersonalAddon.setVisibility(View.GONE);
                frameSeopVehicleBasic.setVisibility(View.GONE);
                frameSeopVehicleAddon.setVisibility(View.GONE);
                frameJL2Go.setVisibility(View.GONE);
                break;
        }
    }
}
