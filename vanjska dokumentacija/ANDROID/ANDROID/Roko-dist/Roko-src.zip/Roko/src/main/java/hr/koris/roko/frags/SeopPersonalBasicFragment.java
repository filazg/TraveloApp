package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Locale;

import hr.akd.tesserapojos.cardsettings.SeopCardSettings;
import hr.koris.roko.R;

public class SeopPersonalBasicFragment extends Fragment {
    final SimpleDateFormat datum = new SimpleDateFormat(SeopCardSettings.DATE_FORMAT, new Locale("hr"));

    TextView vFirstName;
    TextView vSurname;
    TextView vOIB;
    TextView vStatus;
    TextView vUlicaKBr;
    TextView vMjesto;
    TextView vOznMjesta;
    TextView vOpcina;
    TextView vOznOpcine;
    TextView vOtok;
    TextView vBrIskaznice;
    TextView vDatIzdavanja;
    TextView vDatIsteka;
    TextView vOsnPravo;
    TextView vDodatnoPolje1;
    TextView vDodatnoPolje2;
    TextView vDodatnoPolje3;
    TextView vDodatnoPolje4;
    TextView vDodatnoPolje5;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_seop_p_basic, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vFirstName = v.findViewById(R.id.SEOP_P_FirstName);
        vSurname = v.findViewById(R.id.SEOP_P_Surname);
        vOIB = v.findViewById(R.id.SEOP_P_OIB);
        vStatus = v.findViewById(R.id.SEOP_P_Status);
        vUlicaKBr = v.findViewById(R.id.SEOP_P_UlicaKBr);
        vMjesto = v.findViewById(R.id.SEOP_P_Mjesto);
        vOznMjesta = v.findViewById(R.id.SEOP_P_OznMjesta);
        vOpcina = v.findViewById(R.id.SEOP_P_Opcina);
        vOznOpcine = v.findViewById(R.id.SEOP_P_OznOpcine);
        vOtok = v.findViewById(R.id.SEOP_P_Otok);
        vBrIskaznice = v.findViewById(R.id.SEOP_P_BrIskaznice);
        vDatIzdavanja = v.findViewById(R.id.SEOP_P_DatIzdavanja);
        vDatIsteka = v.findViewById(R.id.SEOP_P_DatIsteka);
        vOsnPravo = v.findViewById(R.id.SEOP_P_OsnPravo);
        vDodatnoPolje1 = v.findViewById(R.id.SEOP_P_AdditionalField1);
        vDodatnoPolje2 = v.findViewById(R.id.SEOP_P_AdditionalField2);
        vDodatnoPolje3 = v.findViewById(R.id.SEOP_P_AdditionalField3);
        vDodatnoPolje4 = v.findViewById(R.id.SEOP_P_AdditionalField4);
        vDodatnoPolje5 = v.findViewById(R.id.SEOP_P_AdditionalField5);
    }

    public void fill(hr.akd.tesserapojos.cardfiles.akd.seop.personal.F2_BasicData f) {
        vFirstName.setText(f.FirstName);
        vSurname.setText(f.Surname);
        vOIB.setText(f.OIB);
        vStatus.setText(f.Status.toString());
        vUlicaKBr.setText(f.PermResAddress);
        vMjesto.setText(f.PermResName);
        vOznMjesta.setText(f.PermResCode);
        vOpcina.setText(f.PermResMuniciName);
        vOznOpcine.setText(f.PermResMuniciCode);
        vOtok.setText(f.IslandName);
        vBrIskaznice.setText(f.CardNumber);
        vDatIzdavanja.setText(f.IssuanceDate == null ? "" : datum.format(f.IssuanceDate));
        vDatIsteka.setText(f.ExpirationDate == null ? "" : datum.format(f.ExpirationDate));
        vOsnPravo.setText(f.BasicRight);
        vDodatnoPolje1.setText(f.AdditionalField1);
        vDodatnoPolje2.setText(f.AdditionalField2);
        vDodatnoPolje3.setText(f.AdditionalField3);
        vDodatnoPolje4.setText(f.AdditionalField4);
        vDodatnoPolje5.setText(f.AdditionalField5);
    }
}
