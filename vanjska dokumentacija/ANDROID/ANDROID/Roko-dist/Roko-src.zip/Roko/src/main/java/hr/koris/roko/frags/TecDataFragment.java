package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Arrays;

import hr.akd.tessera.Card;
import hr.akd.tesserapojos.Utils;
import hr.koris.roko.R;

public class TecDataFragment extends Fragment {
    TextView vCardTecType;
    TextView vUID;
    TextView vAppIDs;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_tec_data, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vCardTecType = v.findViewById(R.id.TEC_CardTecType);
        vUID = v.findViewById(R.id.TEC_UID);
        vAppIDs = v.findViewById(R.id.TEC_AppIDs);
    }

    public void fill(Card card) {
        vCardTecType.setText(card.CardTecType != null ? card.CardTecType : "");
        vUID.setText(Utils.convertToHex(card.UID));
        vAppIDs.setText(card.AppIDs != null ? Arrays.toString(card.AppIDs) : "");
    }
}