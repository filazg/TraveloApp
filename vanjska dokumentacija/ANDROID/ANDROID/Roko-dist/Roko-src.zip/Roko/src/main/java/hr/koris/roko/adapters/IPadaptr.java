package hr.koris.roko.adapters;

import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import hr.akd.tesserapojos.strukture.MosiIP;
import hr.koris.roko.R;

public class IPadaptr extends RecyclerView.Adapter<IPadaptr.InvalidskoPravoHolder> {
    final AppCompatActivity mActivity;
    final List<MosiIP> mList;
    final SimpleDateFormat datum = new SimpleDateFormat("yyyy-MM-dd", new Locale("hr"));
    final int nightMode;

    public IPadaptr(AppCompatActivity activity, List<MosiIP> list) {
        mActivity = activity;
        mList = list;
        nightMode = mActivity.getApplicationContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
    }

    @NonNull
    @Override
    public InvalidskoPravoHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.stavka_ip, parent, false);
        return new InvalidskoPravoHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull IPadaptr.InvalidskoPravoHolder holder, int position) {
        MosiIP ip = mList.get(position);
        holder.tvOznIP.setText(ip.getOznIP());
        holder.tvDatKrajIP.setText(ip.getDatIsteka() != null ? datum.format(ip.getDatIsteka()) : mActivity.getResources().getString(R.string.NemaIsteka));
        holder.tvIP_Pratitelj.setText(ip.getOznIpNaPratitelja() != null && !ip.getOznIpNaPratitelja().isEmpty() ? ip.getOznIpNaPratitelja() : mActivity.getResources().getString(R.string.NemaPratitelja));
        holder.tvIP_Vozilo.setText(ip.getOznIpNaVozilo() != null && !ip.getOznIpNaVozilo().isEmpty() ? ip.getOznIpNaVozilo() : mActivity.getResources().getString(R.string.NemaVozila));
        // Na Androidu nema jednostavnog način primjene teme na već napuhnuti prikaz!?!?!!!
        if (position % 2 == 1)
        {
            switch (nightMode) {
                case Configuration.UI_MODE_NIGHT_NO:
                    holder.tvOznIP.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvOznIP.setTextColor(mActivity.getColor(R.color.black));

                    holder.tvDatKrajIP.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvDatKrajIP.setTextColor(mActivity.getColor(R.color.black));

                    holder.tvIP_Pratitelj.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvIP_Pratitelj.setTextColor(mActivity.getColor(R.color.black));

                    holder.tvIP_Vozilo.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvIP_Vozilo.setTextColor(mActivity.getColor(R.color.black));
                    break;
                case Configuration.UI_MODE_NIGHT_YES:
                    holder.tvOznIP.setBackgroundColor(mActivity.getColor(R.color.alt_redak_tamno));
                    holder.tvOznIP.setTextColor(mActivity.getColor(R.color.alt_redak_svijetlo));

                    holder.tvDatKrajIP.setBackgroundColor(mActivity.getColor(R.color.alt_redak_tamno));
                    holder.tvDatKrajIP.setTextColor(mActivity.getColor(R.color.alt_redak_svijetlo));

                    holder.tvIP_Pratitelj.setBackgroundColor(mActivity.getColor(R.color.alt_redak_tamno));
                    holder.tvIP_Pratitelj.setTextColor(mActivity.getColor(R.color.alt_redak_svijetlo));

                    holder.tvIP_Vozilo.setBackgroundColor(mActivity.getColor(R.color.alt_redak_tamno));
                    holder.tvIP_Vozilo.setTextColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    break;
                default:
                    holder.tvOznIP.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvOznIP.setTextColor(mActivity.getColor(R.color.black));

                    holder.tvDatKrajIP.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvDatKrajIP.setTextColor(mActivity.getColor(R.color.black));

                    holder.tvIP_Pratitelj.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvIP_Pratitelj.setTextColor(mActivity.getColor(R.color.black));

                    holder.tvIP_Vozilo.setBackgroundColor(mActivity.getColor(R.color.alt_redak_svijetlo));
                    holder.tvIP_Vozilo.setTextColor(mActivity.getColor(R.color.black));
            }
        }
    }

    @Override
    public int getItemCount() {
        return mList == null ? 0 : mList.size();
    }

    public static class InvalidskoPravoHolder extends RecyclerView.ViewHolder {
        final TextView tvOznIP;
        final TextView tvDatKrajIP;
        final TextView tvIP_Pratitelj;
        final TextView tvIP_Vozilo;

        public InvalidskoPravoHolder(@NonNull View itemView) {
            super(itemView);
            tvOznIP = itemView.findViewById(R.id.tvOznIP);
            tvDatKrajIP = itemView.findViewById(R.id.tvDatKrajIP);
            tvIP_Pratitelj = itemView.findViewById(R.id.tvIP_Pratitelj);
            tvIP_Vozilo = itemView.findViewById(R.id.tvIP_Vozilo);
        }
    }
}