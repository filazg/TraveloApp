package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import hr.koris.roko.R;

public class AkdBizDataFragment extends Fragment {
    TextView vCardBizType;
    TextView vManufacturer;
    TextView vManufactDate;
    TextView vManufactVersion;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_akd_biz_data, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vCardBizType = v.findViewById(R.id.AKD_CardBizType);
        vManufacturer = v.findViewById(R.id.AKD_Manufacturer);
        vManufactDate = v.findViewById(R.id.AKD_ManufactDate);
        vManufactVersion = v.findViewById(R.id.AKD_ManufactVersion);
    }

    public void fill(hr.akd.tesserapojos.cardfiles.akd.F1_BizData f) {
        vCardBizType.setText(f.CardBizType.toString());
        vManufacturer.setText(f.Manufacturer);
        vManufactDate.setText(f.ManufactDate);
        vManufactVersion.setText(f.ManufactVersion);
    }
}