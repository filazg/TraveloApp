package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Locale;

import hr.akd.tesserapojos.cardsettings.SeopCardSettings;
import hr.koris.roko.R;

public class SeopVehicleBasicFragment extends Fragment {
    final SimpleDateFormat datum = new SimpleDateFormat(SeopCardSettings.DATE_FORMAT, new Locale("hr"));

    TextView vRegOznaka;
    TextView vVrstaVozila;
    TextView vImeVlasnika;
    TextView vPrezimeVlasnika;
    TextView vNazivVlasnika;
    TextView vDatRod;
    TextView vOIB;
    TextView vUlicaKBr;
    TextView vMjesto;
    TextView vOznMjesta;
    TextView vOpcina;
    TextView vOznOpcine;
    TextView vBrIskaznice;
    TextView vDatIzdavanja;
    TextView vDatIsteka;
    TextView vOsnPravo;
    TextView vDodatnoPolje1;
    TextView vDodatnoPolje2;
    TextView vDodatnoPolje3;
    TextView vDodatnoPolje4;
    TextView vDodatnoPolje5;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_seop_v_basic, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vRegOznaka = v.findViewById(R.id.SEOP_V_LicensePlateNumber);
        vVrstaVozila = v.findViewById(R.id.SEOP_V_VehicleType);
        vImeVlasnika = v.findViewById(R.id.SEOP_V_OwnerFirstName);
        vPrezimeVlasnika = v.findViewById(R.id.SEOP_V_OwnerSurname);
        vNazivVlasnika = v.findViewById(R.id.SEOP_V_OwnerLegalName);
        vDatRod = v.findViewById(R.id.SEOP_V_OwnerDateOfBirth);
        vOIB = v.findViewById(R.id.SEOP_V_OwnerOIB);
        vUlicaKBr = v.findViewById(R.id.SEOP_V_OwnerPermResAddress);
        vMjesto = v.findViewById(R.id.SEOP_V_OwnerPermResName);
        vOznMjesta = v.findViewById(R.id.SEOP_V_OwnerPermResCode);
        vOpcina = v.findViewById(R.id.SEOP_V_OwnerPermResMuniciName);
        vOznOpcine = v.findViewById(R.id.SEOP_V_OwnerPermResMuniciCode);
        vBrIskaznice = v.findViewById(R.id.SEOP_V_CardNumber);
        vDatIzdavanja = v.findViewById(R.id.SEOP_V_IssuanceDate);
        vDatIsteka = v.findViewById(R.id.SEOP_V_ExpirationDate);
        vOsnPravo = v.findViewById(R.id.SEOP_V_BasicRight);
        vDodatnoPolje1 = v.findViewById(R.id.SEOP_V_AdditionalField1);
        vDodatnoPolje2 = v.findViewById(R.id.SEOP_V_AdditionalField2);
        vDodatnoPolje3 = v.findViewById(R.id.SEOP_V_AdditionalField3);
        vDodatnoPolje4 = v.findViewById(R.id.SEOP_V_AdditionalField4);
        vDodatnoPolje5 = v.findViewById(R.id.SEOP_V_AdditionalField5);
    }

    public void fill(hr.akd.tesserapojos.cardfiles.akd.seop.vehicle.F2_BasicData f) {
        vRegOznaka.setText(f.LicensePlateNumber);
        vVrstaVozila.setText(f.VehicleType);
        vImeVlasnika.setText(f.OwnerFirstName);
        vPrezimeVlasnika.setText(f.OwnerSurname);
        vNazivVlasnika.setText(f.OwnerLegalName);
        vDatRod.setText(f.OwnerDateOfBirth == null ? "" : datum.format(f.OwnerDateOfBirth));
        vOIB.setText(f.OwnerOIB);
        vUlicaKBr.setText(f.OwnerPermResAddress);
        vMjesto.setText(f.OwnerPermResName);
        vOznMjesta.setText(f.OwnerPermResCode);
        vOpcina.setText(f.OwnerPermResMuniciName);
        vOznOpcine.setText(f.OwnerPermResMuniciCode);
        vBrIskaznice.setText(f.CardNumber);
        vDatIzdavanja.setText(f.IssuanceDate == null ? "" : datum.format(f.IssuanceDate));
        vDatIsteka.setText(f.ExpirationDate == null ? "" : datum.format(f.ExpirationDate));
        vOsnPravo.setText(f.BasicRight);
        vDodatnoPolje1.setText(f.AdditionalField1);
        vDodatnoPolje2.setText(f.AdditionalField2);
        vDodatnoPolje3.setText(f.AdditionalField3);
        vDodatnoPolje4.setText(f.AdditionalField4);
        vDodatnoPolje5.setText(f.AdditionalField5);
    }
}
