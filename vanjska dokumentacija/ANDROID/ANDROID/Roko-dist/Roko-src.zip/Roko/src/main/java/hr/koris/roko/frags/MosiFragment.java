package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import hr.akd.tesserapojos.cardsettings.MosiCardSettings;
import hr.akd.tesserapojos.cardfiles.akd.mosi.F2_BasicData;
import hr.akd.tesserapojos.strukture.MosiIP;
import hr.koris.roko.R;
import hr.koris.roko.adapters.IPadaptr;

public class MosiFragment extends Fragment {
    public AppCompatActivity currentActivity;
    final SimpleDateFormat datum = new SimpleDateFormat(MosiCardSettings.DATE_FORMAT, new Locale("hr"));

    TextView vIme;
    TextView vPrezime;
    TextView vOIB;
    TextView vBrIskaznice;
    TextView vSpol;
    TextView vDatRod;
    TextView vUlicaKBr;
    TextView vMjesto;
    TextView vOznMjesta;
    TextView vOpcina;
    TextView vOznOpcine;
    TextView vOtok;
    TextView vDatIzdavanja;
    TextView vDatIsteka;
    TextView vBrIP;
    RecyclerView reciklator;
    IPadaptr adapter;
    List<MosiIP> list;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_mosi, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View view) {
        vIme = view.findViewById(R.id.MOSI_IME);
        vPrezime = view.findViewById(R.id.MOSI_Prezime);
        vOIB = view.findViewById(R.id.MOSI_OIB);
        vBrIskaznice = view.findViewById(R.id.MOSI_BrIskaznice);
        vSpol = view.findViewById(R.id.MOSI_Spol);
        vDatRod = view.findViewById(R.id.MOSI_DatRod);
        vUlicaKBr = view.findViewById(R.id.MOSI_UlicaKBr);
        vMjesto = view.findViewById(R.id.SEOP_P_Mjesto);
        vOznMjesta = view.findViewById(R.id.SEOP_P_OznMjesta);
        vOpcina = view.findViewById(R.id.MOSI_Opcina);
        vOznOpcine = view.findViewById(R.id.SEOP_P_OznOpcine);
        vOtok = view.findViewById(R.id.SEOP_P_Otok);
        vDatIzdavanja = view.findViewById(R.id.SEOP_P_DatIzdavanja);
        vDatIsteka = view.findViewById(R.id.SEOP_P_DatIsteka);
        vBrIP = view.findViewById(R.id.MOSI_BrIP);

        reciklator = view.findViewById(R.id.reciklator);
        reciklator.setLayoutManager(new LinearLayoutManager(requireActivity().getApplicationContext()));
        reciklator.setItemAnimator(new DefaultItemAnimator());
        reciklator.addItemDecoration(new DividerItemDecoration(requireActivity().getApplicationContext(), LinearLayoutManager.VERTICAL));
    }

    public void fill(F2_BasicData f) {
        vIme.setText(f.Ime);
        vPrezime.setText(f.Prezime);
        vOIB.setText(f.OIB);
        vBrIskaznice.setText(f.SBr);
        vSpol.setText(f.Spol.toString());
        vDatRod.setText(f.DatRod == null ? "" : datum.format(f.DatRod));
        vUlicaKBr.setText(f.UlicaKBr);
        vMjesto.setText(f.Mjesto);
        vOznMjesta.setText(f.OznMjesta);
        vOpcina.setText(f.Opcina);
        vOznOpcine.setText(f.OznOpcine);
        vOtok.setText(f.Otok);
        vDatIzdavanja.setText(f.DatIzdavanja == null ? "" : datum.format(f.DatIzdavanja));
        vDatIsteka.setText(f.DatIsteka == null ? "" : datum.format(f.DatIsteka));
        vBrIP.setText(String.format(getString(R.string.BrIP), f.InvalidskaPrava.size()));

        list = f.InvalidskaPrava;
        adapter = new IPadaptr(currentActivity, list);
        reciklator.setAdapter(adapter);

        // Ovisno o zaslonu mobilnog uređaja, ne mora se prikazati čitav reciklator,
        // nego je moguća zbunjujuća pojava "klizanja unutar klizanja".
        // Zato uvijek prikazujem cijeli reciklator.
        int h = 0;
        for (int i = 0; i < adapter.getItemCount(); i++) {
            View stavka = adapter.onCreateViewHolder(reciklator, adapter.getItemViewType(i)).itemView;
            stavka.measure(0, 0);
            h += stavka.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = reciklator.getLayoutParams();
        params.height = h;
        reciklator.setLayoutParams(params);
    }
}