package hr.koris.roko.frags;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Locale;

import hr.akd.tesserapojos.cardsettings.SeopCardSettings;
import hr.koris.roko.R;

public class SeopVehicleAddonFragment extends Fragment {
    final SimpleDateFormat datum = new SimpleDateFormat(SeopCardSettings.DATE_FORMAT, new Locale("hr"));

    TextView vMarka;
    TextView vModel;
    TextView vNamjena;
    TextView vKategorija;
    TextView vDatIstekaPD;
    TextView vMasaPV;
    TextView vMaxMasa;
    TextView vTehMasa;
    TextView vNosivost;
    TextView vDuljina;
    TextView vSirina;
    TextView vVisina;
    TextView vImeKorisnika;
    TextView vPrezimeKorisnika;
    TextView vNazivKorisnika;
    TextView vKorOIB;
    TextView vKorUlicaKBr;
    TextView vKorMjesto;
    TextView vKorOznMjesta;
    TextView vKorOpcina;
    TextView vKorOznOpcine;
    TextView vDodatnoPolje1; // Broj sjedala.
    TextView vDodatnoPolje2;
    TextView vDodatnoPolje3;
    TextView vDodatnoPolje4;
    TextView vDodatnoPolje5;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_seop_v_addon, container, false);
        setupGUI(view);
        return view;
    }

    private void setupGUI(View v) {
        vMarka = v.findViewById(R.id.SEOP_V_VehicleBrand);
        vModel = v.findViewById(R.id.SEOP_V_VehicleModel);
        vNamjena = v.findViewById(R.id.SEOP_V_VehiclePurpose);
        vKategorija = v.findViewById(R.id.SEOP_V_VehicleCategory);
        vDatIstekaPD = v.findViewById(R.id.SEOP_V_TrafficLicenseExpDate);
        vMasaPV = v.findViewById(R.id.SEOP_V_VehicleMass);
        vMaxMasa = v.findViewById(R.id.SEOP_V_VehicleAllowedMass);
        vTehMasa = v.findViewById(R.id.SEOP_V_VehicleTechAllowedMass);
        vNosivost = v.findViewById(R.id.SEOP_V_VehicleAllowedLoad);
        vDuljina = v.findViewById(R.id.SEOP_V_VehicleLength);
        vSirina = v.findViewById(R.id.SEOP_V_VehicleWidth);
        vVisina = v.findViewById(R.id.SEOP_V_VehicleHeight);
        vImeKorisnika = v.findViewById(R.id.SEOP_V_UserFirstName);
        vPrezimeKorisnika = v.findViewById(R.id.SEOP_V_UserSurname);
        vNazivKorisnika = v.findViewById(R.id.SEOP_V_UserLegalName);
        vKorOIB = v.findViewById(R.id.SEOP_V_UserOIB);
        vKorUlicaKBr = v.findViewById(R.id.SEOP_V_UserPermResAddress);
        vKorMjesto = v.findViewById(R.id.SEOP_V_UserPermResidenceName);
        vKorOznMjesta = v.findViewById(R.id.SEOP_V_UserPermResCode);
        vKorOpcina = v.findViewById(R.id.SEOP_V_UserPermResMuniciName);
        vKorOznOpcine = v.findViewById(R.id.SEOP_V_UserPermResMuniciCode);
        vDodatnoPolje1 = v.findViewById(R.id.SEOP_V_AdditionalField1); // Broj sjedala.
        vDodatnoPolje2 = v.findViewById(R.id.SEOP_V_AdditionalField2);
        vDodatnoPolje3 = v.findViewById(R.id.SEOP_V_AdditionalField3);
        vDodatnoPolje4 = v.findViewById(R.id.SEOP_V_AdditionalField4);
        vDodatnoPolje5 = v.findViewById(R.id.SEOP_V_AdditionalField5);
    }

    public void fill(hr.akd.tesserapojos.cardfiles.akd.seop.vehicle.F3_AddonData f) {
        vMarka.setText(f.VehicleBrand);
        vModel.setText(f.VehicleModel);
        vNamjena.setText(f.VehiclePurpose);
        vKategorija.setText(f.VehicleCategory);
        vDatIstekaPD.setText(f.TrafficLicenseExpDate == null ? "" : datum.format(f.TrafficLicenseExpDate));
        vMasaPV.setText(String.valueOf(f.VehicleMass));
        vMaxMasa.setText(String.valueOf(f.VehicleAllowedMass));
        vTehMasa.setText(String.valueOf(f.VehicleTechAllowedMass));
        vNosivost.setText(String.valueOf(f.VehicleAllowedLoad));
        vDuljina.setText(String.valueOf(f.VehicleLength));
        vSirina.setText(String.valueOf(f.VehicleWidth));
        vVisina.setText(String.valueOf(f.VehicleHeight));
        vImeKorisnika.setText(f.UserFirstName);
        vPrezimeKorisnika.setText(f.UserSurname);
        vNazivKorisnika.setText(f.UserLegalName);
        vKorOIB.setText(f.UserOIB);
        vKorUlicaKBr.setText(f.UserPermResAddress);
        vKorMjesto.setText(f.UserPermResidenceName);
        vKorOznMjesta.setText(f.UserPermResidenceCode);
        vKorOpcina.setText(f.UserPermResMuniciName);
        vKorOznOpcine.setText(f.UserPermResMuniciCode);
        vDodatnoPolje1.setText(String.valueOf(f.AdditionalField1)); // Broj sjedala.
        vDodatnoPolje2.setText(f.AdditionalField2);
        vDodatnoPolje3.setText(f.AdditionalField3);
        vDodatnoPolje4.setText(f.AdditionalField4);
        vDodatnoPolje5.setText(f.AdditionalField5);
    }
}
